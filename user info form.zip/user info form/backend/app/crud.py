from .db import SessionLocal
from .models import UserInfo


def create_user(*, name: str, email: str, phone_number: str, message: str) -> UserInfo:
    db = SessionLocal()
    try:
        user = UserInfo(name=name, email=email, phone_number=phone_number, message=message)
        db.add(user)
        db.commit()
        db.refresh(user)
        return user
    finally:
        db.close()


def list_users():
    db = SessionLocal()
    try:
        return (
            db.query(UserInfo)
            .order_by(UserInfo.created_at.desc())
            .all()
        )
    finally:
        db.close()

