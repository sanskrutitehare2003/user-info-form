import os
from typing import List

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .db import engine
from .models import Base, UserInfo
from .crud import create_user, list_users
from pydantic import BaseModel, EmailStr

from .schemas import SubmitPayload



app = FastAPI(title="User Info API")

# CORS for local dev
origins = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in origins if o.strip()],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)







@app.on_event("startup")
def on_startup() -> None:
    # Create tables if they don't exist
    Base.metadata.create_all(bind=engine)


@app.post("/api/submit")
def submit(payload: SubmitPayload):
    created = create_user(
        name=payload.name.strip(),
        email=str(payload.email).strip().lower(),
        phone_number=payload.phone_number.strip(),
        message=payload.message.strip(),
    )
    return {"ok": True, "id": created.id}


class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    phone_number: str
    message: str
    created_at: str | None = None




@app.get("/api/users", response_model=List[UserOut])
def get_users():
    return [
        {
            "id": u.id,
            "name": u.name,
            "email": u.email,
            "phone_number": u.phone_number,
            "message": u.message,
            "created_at": u.created_at.isoformat() if u.created_at is not None else None,
        }
        for u in list_users()
    ]


