from pydantic import BaseModel, EmailStr, Field


class SubmitPayload(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    phone_number: str = Field(min_length=7, max_length=25)
    message: str = Field(min_length=1, max_length=2000)

