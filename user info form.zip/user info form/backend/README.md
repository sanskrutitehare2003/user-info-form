Backend (FastAPI)

Runs an API for submitting and listing user info.

Endpoints:
- POST /api/submit
- GET /api/users

Required DB connection vars (Docker Compose provided in repo):
- DB_HOST
- DB_PORT
- DB_NAME
- DB_USER
- DB_PASSWORD

CORS_ORIGINS defaults to http://localhost:5173,http://localhost:3000

