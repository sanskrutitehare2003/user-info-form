# User Info Form (React + FastAPI + PostgreSQL)

## What it does
- React form collects: **name, email, phone number, message**
- Submits to FastAPI **without page reload**
- Saves submissions to **PostgreSQL**
- `/users` page fetches and displays all saved rows

---

## Requirements
- Node.js 18+
- Python 3.11+
- Docker (optional but recommended for PostgreSQL)

---

## Run everything (recommended: Docker for Postgres + backend, local Vite for frontend)

### 1) Start backend + PostgreSQL
From the repo root:
```powershell
docker compose up -d --build
```

Backend will be available at: `http://localhost:8000`

### 2) Start the frontend
In a separate terminal:
```powershell
cd frontend
npm install
npm run dev
```

Frontend will be available at: `http://localhost:5173`

> Frontend dev server proxies `/api` to `http://localhost:8000`, so you should not see CORS issues.

---

## Alternative: run backend locally (skip docker backend)
### 1) Create virtual env
```powershell
cd backend
python -m venv .venv
.\scripts\Activate.ps1
```

### 2) Install deps
```powershell
pip install -r requirements.txt
```

### 3) Run
```powershell
python run.py
```

Backend runs on `http://localhost:8000`.

---

## Backend (FastAPI)
### 1) Create virtual env
```powershell
cd backend
python -m venv .venv
.scripts\activate
```
(If the above doesn’t work on your shell, run `.scripts\Activate.ps1` instead.)

### 2) Install deps
```powershell
pip install -r requirements.txt
```

### 3) Run
```powershell
python run.py
```
Backend runs on `http://localhost:8000`.

---

## Frontend (React + Tailwind)
From the repo root:
```powershell
cd frontend
npm install
npm run dev
```
Frontend runs on `http://localhost:5173`.

---

## Open in browser
- Form: `http://localhost:5173/`
- Stored data: `http://localhost:5173/users`

---

## Notes
- Backend uses env vars for DB connection. Docker Compose provides defaults.
- On server startup, tables are created automatically (no migrations).

