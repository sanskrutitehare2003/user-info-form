- [ ] Create docker-compose.yml for PostgreSQL + env wiring
- [x] Create backend (FastAPI) with SQLAlchemy + Pydantic validation

- [x] Create backend endpoints: POST /api/submit, GET /api/users

- [ ] Create database schema (SQLAlchemy model + migrations optional)
- [x] Create frontend (Vite React + Tailwind) form with client-side validation

- [x] Create frontend pages: / (submit form) and /users (fetch + display)

- [ ] Wire frontend to backend via fetch (no reload)
- [x] Docker-compose wiring for Postgres + backend
- [x] Update README with proper run instructions
- [ ] Smoke test: submit sample -> verify DB + /users display



