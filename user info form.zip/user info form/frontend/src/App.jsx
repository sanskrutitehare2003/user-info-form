import React from 'react'
import { Navigate, Route, Routes, Link } from 'react-router-dom'
import UserFormPage from './pages/UserFormPage'
import UsersPage from './pages/UsersPage'

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-4 py-4">
          <h1 className="text-lg font-semibold">User Info</h1>
          <nav className="flex gap-4 text-sm">
            <Link className="text-blue-600 hover:underline" to="/">
              Submit
            </Link>
            <Link className="text-blue-600 hover:underline" to="/users">
              View Data
            </Link>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-6">
        <Routes>
          <Route path="/" element={<UserFormPage />} />
          <Route path="/users" element={<UsersPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  )
}

