import React, { useEffect, useState } from 'react'

export default function UsersPage() {
  const [rows, setRows] = useState([])
  async function load() {
    try {
      const res = await fetch('/api/users')
      const data = await res.json().catch(() => ([]))
      if (!res.ok) return
      setRows(Array.isArray(data) ? data : [])
    } catch {
      return
    }
  }


  useEffect(() => {
    load()
  }, [])

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-xl font-semibold">Stored User Data</h2>
        <p className="mt-1 text-sm text-gray-600">Fetched from the backend.</p>
      </div>



      <div className="overflow-auto rounded-lg border bg-white">
        <table className="min-w-[720px] w-full border-collapse text-sm">
          <thead className="bg-gray-50 text-left">
            <tr>
              <th className="border-b px-4 py-2">ID</th>
              <th className="border-b px-4 py-2">Name</th>
              <th className="border-b px-4 py-2">Email</th>
              <th className="border-b px-4 py-2">Phone</th>
              <th className="border-b px-4 py-2">Message</th>
              <th className="border-b px-4 py-2">Created</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-6 text-center text-gray-500">
                  No records found.
                </td>
              </tr>
            ) : (
              rows.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="border-b px-4 py-2">{r.id}</td>
                  <td className="border-b px-4 py-2">{r.name}</td>
                  <td className="border-b px-4 py-2">{r.email}</td>
                  <td className="border-b px-4 py-2">{r.phone_number}</td>
                  <td className="border-b px-4 py-2 max-w-[300px]">
                    <div className="break-words">{r.message}</div>
                  </td>
                  <td className="border-b px-4 py-2">{r.created_at ?? ''}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <button
        className="rounded-md border bg-white px-4 py-2 text-sm hover:bg-gray-50"
        onClick={load}
      >
        Refresh
      </button>
    </div>
  )
}

