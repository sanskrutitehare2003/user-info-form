import React, { useMemo, useState } from 'react'

function validate({ name, email, phone_number, message }) {
  const errors = {}

  const trimmedName = (name ?? '').trim()
  if (!trimmedName) errors.name = 'Name is required.'
  else if (trimmedName.length > 100) errors.name = 'Name must be at most 100 characters.'

  const trimmedEmail = (email ?? '').trim()
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!trimmedEmail) errors.email = 'Email is required.'
  else if (!emailRegex.test(trimmedEmail)) errors.email = 'Enter a valid email address.'

  const trimmedPhone = (phone_number ?? '').trim()
  const digitsOnly = trimmedPhone.replace(/\D/g, '')
  if (!trimmedPhone) errors.phone_number = 'Phone number is required.'
  else if (digitsOnly.length < 7 || digitsOnly.length > 15)
    errors.phone_number = 'Phone number must be 7 to 15 digits.'

  const trimmedMessage = (message ?? '').trim()
  if (!trimmedMessage) errors.message = 'Message is required.'
  else if (trimmedMessage.length < 1) errors.message = 'Message cannot be empty.'
  else if (trimmedMessage.length > 2000) errors.message = 'Message must be at most 2000 characters.'

  return errors
}

export default function UserFormPage() {
  const [form, setForm] = useState({ name: '', email: '', phone_number: '', message: '' })
  const [errors, setErrors] = useState({})
  const isValid = useMemo(() => Object.keys(errors).length === 0, [errors])

  async function onSubmit(e) {
    e.preventDefault()
    const nextErrors = validate(form)
    setErrors(nextErrors)

    if (Object.keys(nextErrors).length > 0) {
      return
    }

    try {
      const res = await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })

      const data = await res.json().catch(() => ({}))

      if (!res.ok || !data.ok) {
        return
      }

      setForm({ name: '', email: '', phone_number: '', message: '' })
      setErrors({})
    } catch (err) {
      return
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Submit your information</h2>
        <p className="mt-1 text-sm text-gray-600">Fields marked with validation will be checked before submit.</p>
      </div>

      <form onSubmit={onSubmit} className="rounded-lg border bg-white p-6 shadow-sm">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="sm:col-span-1">
            <label className="text-sm font-medium" htmlFor="name">
              Name
            </label>
            <input
              id="name"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className="mt-1 w-full rounded-md border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="John Doe"
            />
            {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name}</p>}
          </div>

          <div className="sm:col-span-1">
            <label className="text-sm font-medium" htmlFor="email">
              Email
            </label>
            <input
              id="email"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              className="mt-1 w-full rounded-md border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="john@example.com"
            />
            {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
          </div>

          <div className="sm:col-span-1">
            <label className="text-sm font-medium" htmlFor="phone_number">
              Phone Number
            </label>
            <input
              id="phone_number"
              value={form.phone_number}
              onChange={(e) => setForm((f) => ({ ...f, phone_number: e.target.value }))}
              className="mt-1 w-full rounded-md border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="e.g. 9876543210"
            />
            {errors.phone_number && <p className="mt-1 text-sm text-red-600">{errors.phone_number}</p>}
          </div>

          <div className="sm:col-span-2">
            <label className="text-sm font-medium" htmlFor="message">
              Message
            </label>
            <textarea
              id="message"
              value={form.message}
              onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
              className="mt-1 min-h-[120px] w-full resize-y rounded-md border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Write your message..."
            />
            {errors.message && <p className="mt-1 text-sm text-red-600">{errors.message}</p>}
          </div>
        </div>

        <div className="mt-6 flex items-center justify-end gap-3">
          <button
            type="button"
            className="rounded-md border bg-white px-4 py-2 text-sm hover:bg-gray-50"
            onClick={() => {
              setForm({ name: '', email: '', phone_number: '', message: '' })
              setErrors({})
            }}
          >
            Reset
          </button>
          <button
            type="submit"
            disabled={!isValid && Object.keys(errors).length > 0}
            className="rounded-md bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  )
}


